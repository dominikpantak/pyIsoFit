__author__ = "Dominik Pantak"

from .core.fitting import IsothermFit

